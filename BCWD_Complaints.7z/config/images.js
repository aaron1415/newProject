export const Images = {
  logo: require('../assets/logo.png'),
  dashboard: require('../assets/dashboard.png'),
};
