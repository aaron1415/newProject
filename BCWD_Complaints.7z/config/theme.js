export const Colors = {
  orange: '#f57c00',
  blue: '#039be5',
  black: '#222222',
  white: '#ffffff',
  mediumGray: '#6e6869',
  red: '#E03C32',
  yellow: '#FFD301',
  green: '#006B3D',
  gray: '#EAEBE4'
};
