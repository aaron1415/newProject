import React, { useState, useEffect } from 'react';
import { TouchableOpacity, Image, ImageBackground, StyleSheet, Text, StatusBar, Dimensions } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

import { doc, setDoc, getDoc, deleteDoc, updateDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { updateProfile, deleteUser, signOut } from 'firebase/auth';
import { auth, db, storage, Colors } from '../config';

import { View, TextInput } from '../components';

const { width, height } = Dimensions.get('window');

export const ProfileScreen = ({ navigation }) => {
    const user = auth.currentUser;
    const [fullname, setFullName] = useState(user.displayName);
    const [phonenumber, setPhoneNumber] = useState('');

    const [profileImage, setProfileImage] = useState(user.photoURL);
    const [success, setSuccess] = useState(false);

    const handleUpdate = async () => {
        try {
            await updateProfile(user, {
                displayName: fullname
            });

            await updateDoc(doc(db, 'users', user.uid), {
                fullname: fullname,
                phonenumber: phonenumber,
            });
            setSuccess(true);
        } catch(error) {
            console.log(error.message);
        }
    }

    const handleChoosePhoto = async () => {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();

        if(status !== 'granted') {
            alert('Sorry, we need camera roll permissions to make this work!');
            return;
        }

        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: false,
            aspect: [4, 3],
            quality: 1
        });

        if(!result.cancelled) {
            const imageRef = ref(storage, `profile/${user.uid}/profile.jpg`);
            const image = await fetch(result.uri);
            const bytes = await image.blob();

            await uploadBytes(imageRef, bytes);

            const url = await getDownloadURL(imageRef);

            setProfileImage(url);

            
            await updateProfile(user, {
                photoURL: url
            });
            await updateDoc(doc(db, 'users', user.uid), {
                photoURL: url
            });
        }
    }
    
    const checkUserData = async () => {
        const docRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(docRef);

        if(docSnap.exists()) {
            const { fullname, phonenumber } = docSnap.data();
            setFullName(fullname);
            setPhoneNumber(phonenumber);
        }
    }

    useEffect(() => {
        checkUserData();
    }, []);

    const handleDelete = async () => {
        try {
            const usersRef = doc(db, 'users', user.uid);
            const imageRef = ref(storage, `profile/${user.uid}.jpg`);
            await deleteObject(imageRef);
            await deleteDoc(usersRef);
            deleteUser(user)
                .then(() => {
                    signOut(auth);
                    alert('Account Deleted Successfully!')
                })
                .catch((error) => {
                    console.log(error.message);
                });
        } catch(error) {
            console.log(error);
        }
    }
  return (
    <ImageBackground source={require('../assets/menu.jpg')} style={styles.bg}>
      <View style={styles.container}>
        <StatusBar barStyle="light-content" />
        <View style={styles.logoContainer}>
            {profileImage && <Image source={{ uri: profileImage }} style={styles.profileImage} />}
            <TouchableOpacity style={styles.upload} onPress={handleChoosePhoto}>
                <Text style={styles.uploadText}>
                    {profileImage ? 'Change Profile Picture' : 'Upload Profile Picture'}
                </Text>
            </TouchableOpacity>
            <Text style={styles.screenTitle}>Update Profile</Text>
        </View>
        <View style={styles.profileContainer}>
            <Text style={styles.profileText}>Full Name</Text>
            <TextInput value={fullname} onChangeText={setFullName} />
            <Text style={styles.profileText}>Phone Number</Text>
            <TextInput value={phonenumber} onChangeText={setPhoneNumber} maxLength={11}/>
        </View>
        <View style={styles.buttonsContainer}>
            {success && <Text style={styles.success}>Profile Updated Successfully!</Text>}
            <TouchableOpacity style={styles.button} onPress={ handleUpdate }>
                <Text style={styles.buttonText}>
                    Update Information
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={ handleDelete }>
                <Text style={styles.buttonText}>
                    Delete Account
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={  () => navigation.navigate('Home')  }>
                <Text style={styles.buttonText}>
                Home
                </Text>
            </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0
  },
  logoContainer: {
    alignItems: 'center'
  },
  bg: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    resizeMode: 'contain',
  },
  screenTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.white,
    paddingTop: 20,
    paddingBottom: 20
  },
    profileContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        overflow: 'hidden',
        alignItems: 'center',
        justifyContent: 'center',
        marginHorizontal: width * 0.05,
    },
    profileText: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.white,
        marginTop: 20,
    },
    update: {
        backgroundColor: Colors.secondary,
        borderRadius: 10,
        paddingHorizontal: 20,
        paddingVertical: 10,
        marginTop: 20,
    },
    updateText: {
        color: Colors.white,
        fontWeight: 'bold',
        fontSize: 16,
    },
    profileImageContainer: {
        alignItems: 'center',
        marginBottom: 20,
    },
    profileImage: {
        width: 150,
        height: 150,
        borderRadius: 75,
        borderWidth: 2,
        borderColor: Colors.white,
    },
    buttonsContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        flexWrap: 'wrap',
        marginHorizontal: width * 0.05,
        overflow: 'hidden',
    },
    button: {
        backgroundColor: Colors.orange,
        width: '50%',
        textAlign: 'center',
        borderRadius: 10,
        margin: 10,
        justifyContent: 'space-evenly'
    },
    buttonText: {
        color: Colors.black,
        fontWeight: 'bold',
        textAlign: 'center',
        fontsize: 20,
        margin: 5
    },
    success: {
        color: Colors.orange,
        fontWeight: 'bold',
        textAlign: 'center',
        fontSize: 10,
        marginBottom: 20,
    },
});