import React, { useState, useEffect } from 'react';
import { TouchableOpacity, FlatList, ImageBackground, StyleSheet, Text, StatusBar, Dimensions, Platform } from 'react-native';
import { auth, db, Colors } from '../config';
import { View } from '../components';
import { getDoc, doc, collection, getDocs } from 'firebase/firestore';
import 'react-native-get-random-values';

const { width, height } = Dimensions.get('window');

export const HistoryScreen = ({ navigation }) => {
    const user = auth.currentUser;
    const [complaints, setComplaints] = useState([]);

    useEffect( () => {
        getData();
    }, []);
    const getData = async () => {
        const userDocRef = doc(db, 'users', user.uid);
        const userDocSnap = await getDoc(userDocRef);

        if(userDocSnap.exists()) {
            const complaintsCollectionRef = collection(userDocRef, 'complaints');
            const complaintsCollectionSnap = await getDocs(complaintsCollectionRef);

            const complaints = [];
            complaintsCollectionSnap.forEach(doc => {
                const data = doc.data();
                complaints.push({id: doc.id, ...data});
            });
            setComplaints(complaints);
        }
    }
    const renderItem = ({ item }) => (
        <TouchableOpacity style={styles.item}  onPress={ () => navigation.navigate('ViewComplaint', { complaints: item}) }>
            <Text style={styles.itemTitle}>{item.title}</Text>
            <Text style={styles.itemComplaint}>Type of Complaint: {item.complaint}</Text>
            <Text style={styles.timestamp}>{new Date(item.timestamp.seconds * 1000).toLocaleDateString('en-US')}</Text>
            <Text style={[styles.itemProgress, {color: item.progress === "Verifying" ? Colors.yellow :  item.progress === "Completed" ? Colors.green : Colors.red}]}>{item.progress}</Text>
        </TouchableOpacity>
    );
    const handleBack = () => {
        navigation.navigate('Home');
    }
  return (
    <ImageBackground source={require('../assets/menu.jpg')} style={styles.bg}>
      <View style={styles.container}>
        <StatusBar barStyle="light-content" />
            <View style={styles.logoContainer}>
                <Text style={styles.screenTitle}>Complaint History</Text>
            </View>
            <View style={styles.complaintsListContainer}>
                    <FlatList
                        data={complaints}
                        renderItem={renderItem}
                        keyExtractor={(item) => item.id}
                    />
            </View>
            <View style={styles.buttonsContainer}>
                <TouchableOpacity style={styles.button} onPress={  () => navigation.navigate('Home')  }>
                    <Text style={styles.buttonText}>
                    Home
                    </Text>
                </TouchableOpacity>
            </View>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
  logoContainer: {
    alignItems: 'center'
  },
  bg: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    resizeMode: 'contain',
  },
  screenTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.white,
    paddingTop: 20,
    paddingBottom: 20
  },
    buttonsContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        flexWrap: 'wrap',
        marginHorizontal: width * 0.05,
        overflow: 'hidden',
    },
    button: {
        backgroundColor: Colors.orange,
        width: '40%',
        textAlign: 'center',
        borderRadius: 10,
        margin: 10,
        justifyContent: 'space-evenly'
    },
    buttonText: {
        color: Colors.black,
        fontWeight: 'bold',
        textAlign: 'center',
        fontsize: 20,
        margin: 5
    },
    complaintsListContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        flexWrap: 'wrap',
        marginHorizontal: width * 0.05,
        overflow: 'hidden',
        margin: 10,
    },
    item: {
        backgroundColor: Colors.gray,
        width: width * 0.8,
        margin: 10,
        padding: 10,
    },
    itemTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: Colors.black,
        textAlign: 'left',
    },
    itemComplaint: {
        fontSize: 12,
        fontWeight: 'bold',
        color: Colors.black,
        textAlign: 'left',
    },
    itemProgress: {
        fontSize: 15,
        fontWeight: 'bold',
        textAlign: 'right',
    },
    timestamp: {
        fontSize: 10,
        fontWeight: 'bold',
        color: Colors.black,
        textAlign: 'left',
    }
});