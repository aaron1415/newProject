import React, { useState } from 'react';
import { Text, StatusBar, StyleSheet } from 'react-native';
import { Formik } from 'formik';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import { View, TextInput, Logo, Button, FormErrorMessage } from '../components';
import { Images, Colors, auth, db } from '../config';
import { useTogglePasswordVisibility } from '../hooks';
import { signupValidationSchema } from '../utils';

export const SignupScreen = ({ navigation }) => {
  const [errorState, setErrorState] = useState('');

  const {
    passwordVisibility,
    handlePasswordVisibility,
    rightIcon,
    handleConfirmPasswordVisibility,
    confirmPasswordIcon,
    confirmPasswordVisibility
  } = useTogglePasswordVisibility();

  const handleSignup = async values => {
    const { fullname, email, phonenumber, password } = values;

    createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        updateProfile(user, {
          displayName: fullname
        });
        return setDoc(doc(db, "users", user.uid), {
          fullname: fullname,
          phonenumber: phonenumber,
          email: user.email
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <View isSafe style={styles.container}>
        <StatusBar barStyle="light-content" />
        <KeyboardAwareScrollView enableOnAndroid={true}>
          {/* LogoContainer: consits app logo and screen title */}
          <View style={styles.logoContainer}>
            <Logo uri={Images.logo} />
            <Text style={styles.screenTitle}>Create Account</Text>
          </View>
          {/* Formik Wrapper */}
          <Formik
            initialValues={{
              fullname: '',
              phonenumber: '',
              email: '',
              password: '',
              confirmPassword: ''
            }}
            validationSchema={signupValidationSchema}
            onSubmit={values => handleSignup(values)}
          >
            {({
              values,
              touched,
              errors,
              handleChange,
              handleSubmit,
              handleBlur
            }) => (
              <>
                {/* Input fields */}
                <TextInput
                  name='fullname'
                  leftIconName='account'
                  placeholder='Enter Full Name'
                  autoCapitalize='none'
                  keyboardType='default'
                  textContentType='fullname'
                  value={values.fullname}
                  onChangeText={handleChange('fullname')}
                  onBlur={handleBlur('fullname')}
                />
                <FormErrorMessage error={errors.fullname} visible={touched.fullname} />
                <TextInput
                  name='email'
                  leftIconName='email'
                  placeholder='Enter Email'
                  autoCapitalize='none'
                  keyboardType='email-address'
                  textContentType='emailAddress'
                  value={values.email}
                  onChangeText={handleChange('email')}
                  onBlur={handleBlur('email')}
                />
                <FormErrorMessage error={errors.email} visible={touched.email} />
                <TextInput
                  name='phonenumber'
                  leftIconName='cellphone'
                  placeholder='Enter Phone Number'
                  autoCapitalize='none'
                  keyboardType='numeric'
                  textContentType='telephoneNumber'
                  value={values.phonenumber}
                  onChangeText={handleChange('phonenumber')}
                  onBlur={handleBlur('phonenumber')}
                  maxLength={11}
                />
                <FormErrorMessage error={errors.phonenumber} visible={touched.phonenumber} />
                <TextInput
                  name='password'
                  leftIconName='key-variant'
                  placeholder='Enter password'
                  autoCapitalize='none'
                  autoCorrect={false}
                  secureTextEntry={passwordVisibility}
                  textContentType='newPassword'
                  rightIcon={rightIcon}
                  handlePasswordVisibility={handlePasswordVisibility}
                  value={values.password}
                  onChangeText={handleChange('password')}
                  onBlur={handleBlur('password')}
                />
                <FormErrorMessage
                  error={errors.password}
                  visible={touched.password}
                />
                <TextInput
                  name='confirmPassword'
                  leftIconName='key-variant'
                  placeholder='Confirm password'
                  autoCapitalize='none'
                  autoCorrect={false}
                  secureTextEntry={confirmPasswordVisibility}
                  textContentType='password'
                  rightIcon={confirmPasswordIcon}
                  handlePasswordVisibility={handleConfirmPasswordVisibility}
                  value={values.confirmPassword}
                  onChangeText={handleChange('confirmPassword')}
                  onBlur={handleBlur('confirmPassword')}
                />
                <FormErrorMessage
                  error={errors.confirmPassword}
                  visible={touched.confirmPassword}
                />
                {/* Display Screen Error Mesages */}
                {errorState !== '' ? (
                  <FormErrorMessage error={errorState} visible={true} />
                ) : null}
                {/* Signup button */}
                <Button style={styles.button} onPress={handleSubmit}>
                  <Text style={styles.buttonText}>Signup</Text>
                </Button>
              </>
            )}
          </Formik>
          {/* Button to navigate to Login screen */}
          <Button
            style={styles.borderlessButtonContainer}
            borderless
            title={'Already have an account?'}
            onPress={() => navigation.navigate('Login')}
          />

        </KeyboardAwareScrollView>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
    flex: 1
  },
  logoContainer: {
    alignItems: 'center'
  },
  screenTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.white,
    paddingTop: 20,
    paddingBottom: 20
  },
  button: {
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
    backgroundColor: Colors.orange,
    padding: 10,
    borderRadius: 8
  },
  buttonText: {
    fontSize: 20,
    color: Colors.white,
    fontWeight: '700'
  },
  borderlessButtonContainer: {
    marginTop: 16,
    alignItems: 'center',
    justifyContent: 'center',
  }
});
