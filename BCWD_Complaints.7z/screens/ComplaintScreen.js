import React, { useState, useEffect } from 'react';
import { TouchableOpacity, Image, ImageBackground, StyleSheet, Text, StatusBar, Dimensions } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { auth, db, storage, Colors, Images } from '../config';
import DropDownPicker from 'react-native-dropdown-picker';
import { View, TextInput, Logo } from '../components';
import { setDoc, doc, serverTimestamp } from 'firebase/firestore';
import { uploadBytes, ref, getDownloadURL, deleteObject } from 'firebase/storage';
import 'react-native-get-random-values';
import { v4 as uuidv4 } from 'uuid';

const { width, height } = Dimensions.get('window');

export const ComplaintScreen = ({ navigation }) => {
    let fileNumber = 1;
    const user = auth.currentUser;
    const [uuid, setUUID] = useState('');
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState(null);
    const [complaint, setComplaint] = useState([
        {label: 'Technical Request', value: 'Technical Request'},
        {label: 'Power Outage', value: 'General Request'},
        {label: 'Billing Concerns', value: 'Billing Concerns'},
        {label: 'Service Issues', value: 'Service Issues'},
        {label: 'Other Concerns', value: 'Other Concerns'},
    ]);

    const [name, setName] = useState('');
    const [photo, setPhoto] = useState('');
    const [title, setTitle] = useState('');
    const [location, setLocation] = useState('');
    const [contactNumber, setContactNumber] = useState('');
    const [accountNumber, setAccountNumber] = useState('');
    const [description, setDescription] = useState('');
    const [progress, setProgress] = useState('');
    const [photos, setPhotos] = useState([]);
    const [urls, setUrls] = useState([]);
    const [remarks, setRemarks] = useState('');
    const [message, setMessage] = useState('');

    useEffect(() => {
        setUUID(uuidv4());
    }, []);
    const handleComplaint = async () => {
        const docRef = await setDoc(doc(db, `users/${user.uid}`, `complaints/${uuid}`), {
            name: user.displayName,
            photo: user.photoURL,
            complaint: value,
            title: title,
            location: location,
            contactNumber: contactNumber,
            accountNumber: accountNumber,
            description: description,
            urls: urls,
            remarks: remarks,
            progress: 'Verifying',
            timestamp: serverTimestamp(),
        });
        alert('Complaint submitted successfully');
        navigation.navigate('Home');
        setUUID(null);
    };
    const selectPhotos = async () => {
        setUrls([]);
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
            alert('Sorry, we need camera roll permissions to make this work!');
        }
        
        const results = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: false,
            aspect: [4, 3],
            allowsMultipleSelection: true,
            quality: 1,
        });
        const images = results.selected? results.selected : [results];
        await images.forEach((image) => handleImage(image));
        setMessage('Image uploaded successfully');
    };
    const handleImage = async (image) => {
        const filename = `image-${fileNumber++}`;
        try {
            if (!image.canceled) {
                const img = await fetchImageFromUri(image.uri);
                const uploadUrl = await uploadImage(filename, img);
                downloadImage(uploadUrl);
            }
        } catch (e)  {
            setMessage('Something went wrong');
        }
    };
    const uploadImage = async (filename, img) => {
        console.log(uuid);
        const storageRef = ref(storage, `complaints/${user.uid}/${uuid}/${filename}`);
        await uploadBytes(storageRef, img);
        const downloadURL = await getDownloadURL(storageRef);
        return downloadURL;
    };
    const downloadImage = async (downloadURL) => {
        setUrls((urls) => [...urls, downloadURL]);
    };
    const fetchImageFromUri = async (uri) => {
        const response = await fetch(uri);
        const blob = await response.blob();
        return blob;
    };
    const handleBack = () => {
        urls.forEach((url) => deleteImage(url));
        navigation.navigate('Home');
        setUUID(null);
    };
    const deleteImage = async (url) => {
        const storageRef = ref(storage, url);
        console.log(storageRef);
        await deleteObject(storageRef);
    };
  return (
    <ImageBackground source={require('../assets/menu.jpg')} style={styles.bg}>
      <View style={styles.container}>
        <StatusBar barStyle="light-content" />
            <View style={styles.logoContainer}>
                <Text style={styles.screenTitle}>Report Complaint</Text>
            </View>
            <View style={styles.dropdownComplaints}>
                <DropDownPicker
                    style = {styles.dropdown}
                    open={open}
                    value={value}
                    items={complaint}
                    setOpen={setOpen}
                    setValue={setValue}
                    setItems={setComplaint}
                    placeholder="Select Complaint"
                    placeholderStyle={styles.placeholderStyles}
                />
            </View>
            <KeyboardAwareScrollView enableOnAndroid={true}>
                <View style={styles.fieldContainer}>
                    <TextInput
                        placeholder="Title"
                        placeholderTextColor={Colors.mediumGray}
                        onChangeText={setTitle}
                    />
                    <TextInput
                        placeholder="Location"
                        placeholderTextColor={Colors.mediumGray}
                        onChangeText={setLocation}
                    />
                    <TextInput
                        placeholder="Contact Number"
                        placeholderTextColor={Colors.mediumGray}
                        onChangeText={setContactNumber}
                    />
                    <TextInput
                        placeholder="Account Number"
                        placeholderTextColor={Colors.mediumGray}
                        onChangeText={setAccountNumber}
                    />
                    <TextInput
                        placeholder="Description"
                        placeholderTextColor={Colors.mediumGray}
                        onChangeText={setDescription}
                        numberOfLines={3}
                    />
                    <View style={styles.statusContainer}>
                        <Text style={styles.statusText}>{message}</Text>
                    </View>
                </View>
                <View style={styles.buttonsContainer}>
                    <TouchableOpacity style={styles.button} onPress={  selectPhotos }>
                        <Text style={styles.buttonText}>
                        Upload Photos
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.button} onPress={  handleComplaint  }>
                        <Text style={styles.buttonText}>
                        Send Complaint
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.button} onPress={  handleBack  }>
                        <Text style={styles.buttonText}>
                        Home
                        </Text>
                    </TouchableOpacity>
                </View>
            </KeyboardAwareScrollView>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
  logoContainer: {
    alignItems: 'center'
  },
  bg: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    resizeMode: 'contain',
  },
  screenTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.white,
    paddingTop: 20,
    paddingBottom: 20
  },
    dropdownComplaints: {
        width: 300,
        zIndex: 3000,
        alignSelf: 'center',
        marginVertical: 8,
    },
    dropdown: {
        bordercolor: "#B7B7B7",
        height: 50,
        borderRadius: 0
    },
    placeholderStyles: {
        color: Colors.mediumGray,
    },
    fieldContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
    },
    buttonsContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        flexWrap: 'wrap',
        marginHorizontal: width * 0.05,
        overflow: 'hidden',
    },
    button: {
        backgroundColor: Colors.orange,
        width: '40%',
        textAlign: 'center',
        borderRadius: 10,
        margin: 10,
        justifyContent: 'space-evenly'
    },
    buttonText: {
        color: Colors.black,
        fontWeight: 'bold',
        textAlign: 'center',
        fontsize: 20,
        margin: 5
    },
    statusContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        flexWrap: 'wrap',
        marginHorizontal: width * 0.05,
        overflow: 'hidden',
    },
    statusText: {
        color: Colors.white,
        fontWeight: 'bold',
        textAlign: 'center',
        fontSize: 20,
        marginBottom: 20,
    },
    statusTextColor: {
        color: Colors.yellow,
        fontWeight: 'bold',
        textAlign: 'center',
        fontSize: 20,
        marginBottom: 20,
    },
});